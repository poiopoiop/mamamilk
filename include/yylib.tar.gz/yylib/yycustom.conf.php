<?php

ini_set("display_errors",'On');
ini_set("memory_limit",'2048M');

define('CURL_PROXY','10.38.156.60:8888');
define('LOG_LEVEL',"NOTICE");
define('LOG_PATH','/home/iknow/yuyang09/log/');
define('DATA_PATH','/home/iknow/yuyang09/data/');
define('LOG_NAME','yy.log');

?>
