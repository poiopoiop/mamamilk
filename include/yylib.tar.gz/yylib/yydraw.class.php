<?php
require_once(dirname(__file__)."/lib/phpchartdir.php");

define('DRAW_FONT','simhei.ttf');

class yydraw {
	public $drawPic = NULL;
	public $drawTitle = NULL;

	public function __construct($title) {
		$this->drawTitle = $title;
	}

	public function drawBar($data,$labels) {

		# Create a XYChart object of size 600 x 380 pixels. Set background color to brushed
		# silver, with a 2 pixel 3D border. Use rounded corners of 20 pixels radius.
		$c = new XYChart(930, 520, brushedSilverColor(), Transparent, 2);
		$c->swapXY();

		# Add a title to the chart using 18pts Times Bold Italic font. Set top/bottom margins
		# to 8 pixels.
		$textBoxObj = $c->addTitle("$this->drawTitle", DRAW_FONT, 24);
		$textBoxObj->setMargin2(0, 0, 8, 8);

		# Set the plotarea at (70, 55) and of size 460 x 280 pixels. Use transparent border
		# and black grid lines. Use rounded frame with radius of 20 pixels.
		$c->setPlotArea(220, 80, 750, 400, -1, -1, Transparent, 0x000000);
		$c->setRoundedFrame(0xffffff, 20);

		# Add a multi-color bar chart layer using the supplied data. Set cylinder bar shape.
		$barLayerObj = $c->addBarLayer3($data);
		$barLayerObj->setBarShape(CircleShape);

		# Set the labels on the x axis.
		$c->xAxis->setLabels($labels);

		# Show the same scale on the left and right y-axes
		$c->syncYAxis();

		# Set the left y-axis and right y-axis title using 10pt Arial Bold font
		//$c->yAxis->setTitle("USD (millions)", "simsun.ttc", 10);
		//$c->yAxis2->setTitle("USD (millions)", "simsun.ttc", 10);

		# Set y-axes to transparent
		$c->yAxis->setColors(Transparent);
		$c->yAxis2->setColors(Transparent);

		# Disable ticks on the x-axis by setting the tick color to transparent
		$c->xAxis->setTickColor(Transparent);

		# Set the label styles of all axes to 8pt Arial Bold font
		$c->xAxis->setLabelStyle(DRAW_FONT, 11);
		$c->yAxis->setLabelStyle(DRAW_FONT, 9);
		$c->yAxis2->setLabelStyle(DRAW_FONT, 9);

		$this->drawPic = $c->makeChart2(JPG);
		return $this->drawPic;
	}

	public function drawPie ($data,$labels) {
		# Create a PieChart object of size 560 x 270 pixels, with a golden background and a 1
		# pixel 3D border
		$c = new PieChart(930, 520, goldColor(), -1, 1);

		# Add a title box using 15 pts Times Bold Italic font and metallic pink background
		# color
		$textBoxObj = $c->addTitle($this->drawTitle, DRAW_FONT, 15);
		$textBoxObj->setBackground(metalColor(0xff9999));

		# Set the center of the pie at (280, 135) and the radius to 110 pixels
		$c->setPieSize(465, 260, 180);

		# Draw the pie in 3D with 20 pixels 3D depth
		$c->set3D(40);

		# Use the side label layout method
		$c->setLabelLayout(SideLayout);

		# Set the label box background color the same as the sector color, with glass effect,
		# and with 5 pixels rounded corners
		$t = $c->setLabelStyle(DRAW_FONT, 12);
		$t->setBackground(SameAsMainColor, Transparent, glassEffect());
		$t->setRoundedCorners(5);

		# Set the border color of the sector the same color as the fill color. Set the line
		# color of the join line to black (0x0)
		$c->setLineColor(SameAsMainColor, 0x000000);

		# Set the start angle to 135 degrees may improve layout when there are many small
		# sectors at the end of the data array (that is, data sorted in descending order). It
		# is because this makes the small sectors position near the horizontal axis, where
		# the text label has the least tendency to overlap. For data sorted in ascending
		# order, a start angle of 45 degrees can be used instead.
		$c->setStartAngle(135);

		# Set the pie data and the pie labels
		$c->setData($data, $labels);

		$this->drawPic = $c->makeChart2(JPG);
		return $this->drawPic;
	}

	public function drawCompareBar ($data_week,$data_total,$labels) {

		# Create a XYChart object of size 540 x 375 pixels
		$c = new XYChart(900, 500);

		# Add a title to the chart using 18 pts Times Bold Italic font
		$c->addTitle($this->drawTitle, DRAW_FONT, 18);

		# Set the plotarea at (50, 55) and of 440 x 280 pixels in size. Use a vertical
		# gradient color from light red (ffdddd) to dark red (880000) as background. Set
		# border and grid lines to white (ffffff).
		$c->setPlotArea(50, 55, 440, 280, $c->linearGradientColor(0, 55, 0, 335, 0xffdddd,
		    0x880000), -1, 0xffffff, 0xffffff);

		# Add a legend box at (50, 25) using horizontal layout. Use 10pts Arial Bold as font,
		# with transparent background.
		$legendObj = $c->addLegend(50, 25, false, DRAW_FONT, 10);
		$legendObj->setBackground(Transparent);

		# Set the x axis labels
		$c->xAxis->setLabels($labels);

		# Draw the ticks between label positions (instead of at label positions)
		$c->xAxis->setTickOffset(0.5);

		# Set axis label style to 8pts Arial Bold
		$c->xAxis->setLabelStyle(DRAW_FONT, 8);
		$c->yAxis->setLabelStyle(DRAW_FONT, 8);

		# Set axis line width to 2 pixels
		$c->xAxis->setWidth(2);
		$c->yAxis->setWidth(2);

		# Add axis title
		$c->yAxis->setTitle("Throughput (MBytes Per Hour)");

		# Add a multi-bar layer with 3 data sets and 4 pixels 3D depth
		$layer = $c->addBarLayer2(Side, 4);
		$layer->addDataSet($data_week, 0xffff00, "一周数据");
		$layer->addDataSet($data_total, 0x00ff00, "总数据");

		# Set bar border to transparent. Use soft lighting effect with light direction from
		# top.
		$layer->setBorderColor(Transparent, softLighting(Top));

		# Configure the bars within a group to touch each others (no gap)
		$layer->setBarGap(0.2, TouchBar);

		$this->drawPic = $c->makeChart2(JPG);
		return $this->drawPic;
	}
}
