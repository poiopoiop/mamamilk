<?php

define('HTML_HEAD',"
<style type='text/css'>\n
div {
	font: Arial, Helvetica, sans-serif; 
	color:#555;
	line-height:150%;
	text-align:left;
	margin:0 20px;
	width:100%;
	background:#fff;
	padding-bottom:20px;
}\n

table, td{
	font:100% Arial, Helvetica, sans-serif; 
}\n
table{width:450px;border-collapse:collapse;margin:1em 0;}\n
th, td{text-align:left;padding:.5em;border:1px solid #fff;}\n
th{background:#328aa4 url(tr_back.gif) repeat-x;color:#fff;}\n
td{background:#e5f1f4;}\n

tr.even td{background:#e5f1f4;}\n
tr.odd td{background:#f8fbfc;}\n
th.over, tr.even th.over, tr.odd th.over{background:#4a98af;}\n
th.down, tr.even th.down, tr.odd th.down{background:#bce774;}\n
th.selected, tr.even th.selected, tr.odd th.selected{}\n
td.over, tr.even td.over, tr.odd td.over{background:#ecfbd4;}\n
td.down, tr.even td.down, tr.odd td.down{background:#bce774;color:#fff;}\n
td.selected, tr.even td.selected, tr.odd td.selected{background:#bce774;color:#555;}\n
td.empty, tr.odd td.empty, tr.even td.empty{background:#fff;}\n

</style>\n
<div>\n"
);

define('HTML_END',"</div>\n");

class yytable {

	public function buildHtmlTable ($title,$lable,$data) {
		
		if(empty($data)) {
			return NULL;
		}

		// Build table start
		$table_message = "<p><h2>$title<br /></h2><table cellspacing=\"0\" cellpadding=\"0\">\n";

		// Build table lable
		$table_message .= "<tr>\n";
		foreach ( $lable as $col ) {
			$table_message .= "<th>{$col}</th>\n";
		}
		$table_message .= "</tr>\n";

		// Build table data
		foreach ($data as $row) {
			$table_message .= "<tr>\n";
			foreach ( $row as $col ) {
				$table_message .= "<td>{$col}</td>\n";
			}
			$table_message .= "</tr>\n";
		}

		// Build table end
		$table_message .="\n</table></p>\n";

		return $table_message;
	}

	public function buildCsvTable ($file,$data,$mode='a') {
		
		if(empty($data)) {
			return FALSE;
		}

		$fp = fopen($file,$mode);
		foreach ($data as $row) {
			fputcsv($fp,$row);
		}
		fclose($fp);
		return TRUE;
	}
}