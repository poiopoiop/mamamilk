<?php

$GLOBALS['docui']=array(
	'host' => "10.46.139.106",
	'name' => "docshare",
	'user' => "liuwenyu",
	'password' => "rlfwigxuuYRnwz2X",
	'port' => '4040',
);


$GLOBALS['uscore']=array(
	'host' => "10.52.129.73",
	'name' => "ns_doc_uscore",
	'user' => "usc_rd_r",
	'password' => "07865e2E02A67",
	'port' => '5030',
);

$GLOBALS['mis']=array(
	'host' => "10.38.115.54",
	'name' => "docshare",
	'user' => "wenkumis_rd_r",
	'password' => "A133561963B210C",
	'port' => '5010',
);

$GLOBALS['task']=array(
	'host' => "10.38.13.34",
	'name' => "task",
	'user' => "task_rd_r",
	'password' => "1TmdpAkqt5nPtvhO",
	'port' => '5009',
);

$GLOBALS['rec']=array(
	'host' => "10.65.44.168",
	'name' => "ns_doc_rec",
	'user' => "commend_rd_r",
	'password' => "E7C32110CB524E",
	'port' => '4040',
);

$GLOBALS['rrs']=array(
	'host' => "10.65.44.168",
	'name' => "ns_doc_commend",
	'user' => "commend_rd_r",
	'password' => "E7C32110CB524E",
	'port' => '4040',
);

$GLOBALS['ddbs']=array(
	'host' => "10.36.25.36",
	'name' => "ns_doc",
	'user' => "wenku_rd_r",
	'password' => "PpdDwlwsWyKxItAA",
	'port' => '6000',
);

$GLOBALS['weipu']=array(
	'host' => "10.46.139.104",
	'name' => "weipu",
	'user' => "iknow",
	'password' => "YsyhLjt",
	'port' => '3306',
);
