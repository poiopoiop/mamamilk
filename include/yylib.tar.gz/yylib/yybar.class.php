<?php

class yybar {
    private $title;

    public function __construct($title="Progress") {
        $this->title = $title;
        echo "\n";
    }

    public function __destruct() {
        echo "\n";
    }

    public function drawbar($current,$total) {
		if($total == 0 || $total < $current)
		{
			printf("$this->title: Cur: %d Total: %d\r", $current,$total);
		}
		else
		{
			$width = 50;
			$progress = floor($current*100/$total);
			$bar = $progress*$width/100;
			printf("$this->title: [%-50s] %d%% | Cur: %d Total: %d\r", str_repeat('#',$bar), $progress,$current,$total);
		}
    }
}
