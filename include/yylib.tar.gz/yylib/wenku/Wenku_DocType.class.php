<?php

class Wenku_DocType
{
    const NONE = 0;
    const WORD2003 = 1;
    const EXCEL2003 = 2;
    const PPT2003 = 3;
    const WORD2007 = 4;
    const EXCEL2007 = 5;
    const PPT2007 = 6;
    const PDF = 7;
    const TXT = 8;
    const WPS = 9;
    const ET = 10;
    const DPS = 11;
    const VSD = 12;
    const RTF = 13;
    const POT = 14;
    const PPS = 15;
    const EPUB = 16;

    const EXT_NONE = '';
    const EXT_WORD2003 = 'doc';
    const EXT_EXCEL2003 = 'xls';
    const EXT_PPT2003 = 'ppt';
    const EXT_WORD2007 = 'docx';
    const EXT_EXCEL2007 = 'xlsx';
    const EXT_PPT2007 = 'pptx';
    const EXT_PDF = 'pdf';
    const EXT_TXT = 'txt';
    const EXT_WPS = 'wps';
    const EXT_ET = 'et';
    const EXT_DPS = 'dps';
    const EXT_VSD = 'vsd';
    const EXT_RTF = 'rtf';
    const EXT_POT = 'pot';
    const EXT_PPS = 'pps';
    const EXT_EPUB = 'epub';    
    
    const SHOW_TYPE_NONE = '';
    const SHOW_TYPE_DOC = 'doc';
    const SHOW_TYPE_TXT = 'txt';
    const SHOW_TYPE_PPT = 'ppt';

    public static function isValidType($type){

        $types = array(self::WORD2003, self::EXCEL2003, self::PPT2003, self::WORD2007, self::EXCEL2007, self::PPT2007, self::PDF, self::TXT, self::WPS, self::ET, self::DPS, self::VSD, self::RTF, self::POT, self::PPS, self::EPUB);

        return in_array($type, $types); 
    }

    public static function getTypeByExt($ext){
        $map = array(
            self::EXT_NONE  => self::NONE,
            self::EXT_WORD2003  => self::WORD2003,
            self::EXT_EXCEL2003  => self::EXCEL2003,
            self::EXT_PPT2003  => self::PPT2003,
            self::EXT_WORD2007  => self::WORD2007,
            self::EXT_EXCEL2007  => self::EXCEL2007,
            self::EXT_PPT2007  => self::PPT2007,
            self::EXT_PDF  => self::PDF,
            self::EXT_TXT  => self::TXT,
            self::EXT_WPS  => self::WPS,
            self::EXT_ET  => self::ET,
            self::EXT_DPS  => self::DPS,
            self::EXT_VSD  => self::VSD,
            self::EXT_RTF  => self::RTF,
            self::EXT_POT  => self::POT,
            self::EXT_PPS  => self::PPS,
            self::EXT_EPUB  => self::EPUB,
        );
        
        return isset($map[$ext])? $map[$ext] : self::NONE;
    }
    
    public static function getExtByType($type){
        $map = array(
            self::NONE  => self::EXT_NONE,
            self::WORD2003  => self::EXT_WORD2003,
            self::EXCEL2003  => self::EXT_EXCEL2003,
            self::PPT2003  => self::EXT_PPT2003,
            self::WORD2007  => self::EXT_WORD2007,
            self::EXCEL2007  => self::EXT_EXCEL2007,
            self::PPT2007  => self::EXT_PPT2007,
            self::PDF  => self::EXT_PDF,
            self::TXT  => self::EXT_TXT,
            self::WPS  => self::EXT_WPS,
            self::ET  => self::EXT_ET,
            self::DPS  => self::EXT_DPS,
            self::VSD  => self::EXT_VSD,
            self::RTF  => self::EXT_RTF,
            self::POT  => self::EXT_POT,
            self::PPS  => self::EXT_PPS,
            self::EPUB  => self::EXT_EPUB,
        );
        
        return isset($map[$type])? $map[$type] : self::EXT_NONE;
    }
    
    public static function getShowTypeByType($type){
        $map = array(
            self::NONE => self::SHOW_TYPE_NONE,
            self::WORD2003 => self::SHOW_TYPE_DOC,
            self::EXCEL2003 => self::SHOW_TYPE_DOC,
            self::EXCEL2007 => self::SHOW_TYPE_DOC,
            self::WORD2007 => self::SHOW_TYPE_DOC,
            self::PDF => self::SHOW_TYPE_DOC,
            self::VSD => self::SHOW_TYPE_DOC,
            self::EPUB => self::SHOW_TYPE_DOC, 
            self::RTF => self::SHOW_TYPE_DOC,
            self::ET => self::SHOW_TYPE_DOC,
            self::WPS => self::SHOW_TYPE_DOC,
            self::PPT2003 => self::SHOW_TYPE_PPT,            
            self::PPT2007 => self::SHOW_TYPE_PPT,     
            self::TXT => self::SHOW_TYPE_TXT, 
            self::DPS => self::SHOW_TYPE_PPT,  
            self::POT => self::SHOW_TYPE_PPT,
            self::PPS => self::SHOW_TYPE_PPT,
        );
        
        return isset($map[$type])? $map[$type] : self::SHOW_TYPE_NONE;
    }
}
