<?php

class yylog
{
    private $log_path;

    public function __construct($log_folder,$log_name)
    {
        $log_prefix = trim($log_folder);
        @mkdir($log_prefix,0777,true);
        $this->log_path = rtrim($log_prefix,'/')."/".$log_name;
    }

    public function error($msg,$file,$line,$level=0)
    {
		$prefix = "ERROR:";
		$this->show($prefix,$msg,$file,$line,$level);
    }

    public function notice($msg,$file,$line,$level=0)
    {
		$prefix = "NOTICE:";
		if(LOG_LEVEL == "DEBUG" || LOG_LEVEL == "NOTICE")
		{
			$this->show($prefix,$msg,$file,$line,$level);
		}
    }
	
	public function debug($msg,$file,$line,$level=0)
    {
		$prefix = "DEBUG :";
		if(LOG_LEVEL == "DEBUG")
		{
			$this->show($prefix,$msg,$file,$line,$level);
		}
    }

    public function show($prefix,$msg,$file,$line,$level)
    {
		$time = date("Y-m-d H:i:s");
		$filename = basename($file);
		$str = "$prefix # $time # $filename:$line # $msg".PHP_EOL;
		file_put_contents($this->log_path, $str, FILE_APPEND | LOCK_EX);
    }
}
