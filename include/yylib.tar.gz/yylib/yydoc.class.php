<?php

require_once(dirname(__file__).'/yycommon.conf.php');
require_once(dirname(__file__).'/wenku/Wenku_DocType.class.php');

class yydoc
{
    public $doc_id_list = array();
    public $retryList = array();
    private $proxy = NULL;
    private $curl = NULL;
    private $Log = NULL;
    private $bar_flag = FALSE;
    private $doc_bar = NULL;

    const MAX_RETRY_TIMES = 3;
    const MAX_CURL_PROCESS = 1000;

    public function __construct()
    {
        $this->Log = $GLOBALS['Log'];
    }

    public function setProxy($proxy)
    {
        $this->proxy = $proxy;
    }

    public function enableBar($flag)
    {
        $this->bar_flag = $flag;
        if($flag)
        {
            $this->doc_bar = new yybar("Curl");
        }
    }

    public function addDoc($data,$type)
    {
        if(empty($data))
        {
            $this->Log->error("addDoc: data is empty",__FILE__,__LINE__);
            return FALSE;
        }

        switch ($type)
        {
            case 'id':
                $this->doc_id_list[] = array('doc_id' => $data);
                break;

            case 'idlist':
                if(!is_array($data))
                {
                    $this->Log->error("addDoc: params error",__FILE__,__LINE__);
                    return FALSE;
                }
                foreach($data as $row)
                {
                    $this->doc_id_list[] = array('doc_id' => $row);
                }
                break;

            case 'data':
                if(!is_array($data))
                {
                    $this->Log->error("addDoc: params error",__FILE__,__LINE__);
                    return FALSE;
                }
                $this->doc_id_list = array_merge($this->doc_id_list,$data);
                break;
            
            default:
                $this->Log->error("addDoc: unknown type",__FILE__,__LINE__);
                break;
        }
    }

    public function excute()
    {
        if(!$this->buildDocInfo())
        {
            $this->Log->error("yydoc excute error",__FILE__,__LINE__);
            return NULL;
        }

        $total = count($this->doc_id_list);

        $runtimes = ceil($total/self::MAX_CURL_PROCESS);
        for($i=0;$i<$runtimes;$i++)
        {
            $progress = round(($i + 1)*100/$runtimes);
            $this->Log->notice("yydoc excute process: $progress %",__FILE__,__LINE__);
            $offset = $i * self::MAX_CURL_PROCESS;

            $data_slice = array_slice($this->doc_id_list, $offset, self::MAX_CURL_PROCESS,TRUE);
            $this->getOnlineInfo($data_slice);

            if($this->bar_flag)
            {
                $this->doc_bar->drawbar($i+1,$runtimes);
            }
        }

        return $this->doc_id_list;
    }

    private function getOnlineInfo($data_slice)
    {
        $curl = new yycurl($this->proxy);

        foreach ($data_slice as $key => $row)
        {
            $curl_list = array($row['async_url']);
            $callback = array(array($this, 'curlCallback'),array($this,$key));
            $curl->add($curl_list,$callback);
        }

        $curl->go();
        unset($curl);

        // retry curl
        $this->curlRetry();
    }

    private function buildDocInfo()
    {
        if(empty($this->doc_id_list))
        {
            $this->Log->error("buildDocInfo: doc_id_list data empty",__FILE__,__LINE__);
            return FALSE;
        }

        foreach ($this->doc_id_list as &$row)
        {
            $doc_id = $row['doc_id'];
            $row['async_url'] = $this->buildAsyncUrl($doc_id);
            $row['wenku_url'] = $this->buildWenkuUrl($doc_id);

            if(isset($row['type']))
            {
                $row['file_type'] = $this->getFileType($row['type']);
            }

            if(isset($row['size']))
            {
                $row['size'] = $this->formatBytes($row['size']);
            }

            if(isset($row['create_time']))
            {
                $row['create_time'] = date("Y-m-d",$row['create_time']);
            }
        }

        return TRUE;
    }

    public function getFileType($type)
    {
        return Wenku_DocType::getShowTypeByType($type);
    }

    public function curlRetry()
    {
        $retryCount = 0;
        // Retry curl
        while($retryCount < self::MAX_RETRY_TIMES)
        {

            if(empty($this->retryList))
            {
                break;
            }
            
            $internal_retryList = $this->retryList;
            $curl = new yycurl($this->proxy);
            
            foreach ($internal_retryList as $key)
            {
                $doc_record = $this->doc_id_list[$key];
                $curl_list = array($doc_record['async_url']);
                $callback = array(array($this, 'curlCallback'),array($this,$key));
                $curl->add($curl_list,$callback);
            }

            $this->retryList = array();
            $curl->go();
            $retryCount = $retryCount + 1;
        }

        // Wrtie error file
        if(!empty($this->retryList))
        {
            foreach ($this->retryList as $key)
            {
                $doc_record = $this->doc_id_list[$key];
                $doc_id = $doc_record['doc_id'];
                $wenku_url = $doc_record['wenku_url'];
                $this->Log->error("Fetch status error! doc_id: $doc_id, url: $wenku_url", __FILE__, __LINE__, 0);

                $today = date("Y_m_d");
                
                $file_name = DATA_PATH.'CURL_ERROR_FILE_'.$today;
                $dataLine = "$doc_id\t$wenku_url".PHP_EOL;
                file_put_contents($file_name, $dataLine, FILE_APPEND);
            }
        }
    }

    public function buildAsyncUrl($doc_id)
    {
        $online_id = fcrypt_id_2hstr('doc19820829!', $doc_id, 0);
        $prefix_url ="http://wenku.baidu.com/async?atype=docCount&viewCountIncr=0&sl=0&doc_id=";
        $url = $prefix_url.$online_id;
        return $url;
    }

    public function buildWenkuUrl($doc_id)
    {
        $online_id = fcrypt_id_2hstr('doc19820829!', $doc_id, 0);
        $prefix_url ="http://wenku.baidu.com/view/";
        $url = $prefix_url.$online_id.".html";
        return $url;
    }

    public function formatBytes($bytes, $precision = 2)
    { 
        $units = array('B', 'KB', 'MB', 'GB', 'TB'); 

        $bytes = max($bytes, 0); 
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
        $pow = min($pow, count($units) - 1); 

        // Uncomment one of the following alternatives
        $bytes /= pow(1024, $pow);
        // $bytes /= (1 << (10 * $pow)); 

        return round($bytes, $precision) . ' ' . $units[$pow]; 
    }

    public static function curlCallback($webResult,&$yydoc,$key)
    {
        $result = json_decode($webResult['content']);
        if(!empty($result))
        {
            $status =  $result->{'status'};
        }

        // JSON need isset to verify
        if(!isset($status) || ($status != 0))
        {
            $yydoc->retryList[] = $key;
        }
        else
        {
            $doc_record = &$yydoc->doc_id_list[$key];
            // 浏览量
            $doc_record['viewCount'] = $result->{'viewCount'};
            // 下载量
            $doc_record['downloadCount'] = $result->{'downloadCount'};
            // 收藏量
            $doc_record['cangCount'] = $result->{'cangCount'};
            // 评价人数
            $doc_record['valueCount'] = $result->{'valueCount'};
            // 推荐人数
            $doc_record['valueRecommend'] = $result->{'valueRecommend'};
            // 推荐分数
            $doc_record['valueRecRatio'] = $result->{'valueRecRatio'};
            // 推荐星级(除2后保留一位)
            $doc_record['float_valueAverage'] = $result->{'float_valueAverage'};
            $doc_record['doc_star'] = round($doc_record['float_valueAverage']/2,1);
            // 整数评分
            $doc_record['valueAverage'] = $result->{'valueAverage'};    
        }
    }
}
