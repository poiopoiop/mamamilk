<?php

require_once(dirname(__file__).'/yycustom.conf.php');
require_once(dirname(__file__).'/mysql.conf.php');
require_once(dirname(__file__).'/yylog.class.php');
require_once(dirname(__file__).'/yycurl.class.php');
require_once(dirname(__file__).'/yydb.class.php');
require_once(dirname(__file__).'/yymail.class.php');
require_once(dirname(__file__).'/yydraw.class.php');
require_once(dirname(__file__).'/yytable.class.php');
require_once(dirname(__file__).'/yybar.class.php');
require_once(dirname(__file__).'/yydoc.class.php');

$GLOBALS['Log'] = new yylog(LOG_PATH,LOG_NAME);

?>
