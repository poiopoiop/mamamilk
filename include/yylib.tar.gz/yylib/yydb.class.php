<?php

require_once(dirname(__file__).'/yycommon.conf.php');

class yydb
{

    public $conn = NULL;
    public $mysql = NULL;
    private $Log;

    public function __construct($dbname,$debug=FALSE)
    {
        $this->Log = $GLOBALS['Log'];
        $this->initDB($dbname,$debug);
    }
	
    private function initDB($dbname,$debug=FALSE) 
    {
        $db_host = $GLOBALS[$dbname]['host'];
        $db_name = $GLOBALS[$dbname]['name'];
        $db_user = $GLOBALS[$dbname]['user'];
        $db_password = $GLOBALS[$dbname]['password'];
        $db_port = $GLOBALS[$dbname]['port'];

        // Init database connector
        $this->mysql = new mysqli($db_host, $db_user, $db_password, $db_name, $db_port);

    	if(mysqli_connect_errno())
    	{
    	    $this->Log->error("Could not connect to $db_host: ".mysqli_connect_error(),__FILE__,__LINE__);
    	    return FALSE;
    	}
    	else
    	{
            $this->Log->debug("connect to db $db_name in $db_host sucess", __FILE__, __LINE__);
            $this->conn = new yyquery($this->mysql,$debug);
            return TRUE;
        }
    }
}

class yyquery
{
    public $mysql = NULL;
    public $result = array();
    private $Log = NULL;
	private $debug_flag = FALSE;

    public function __construct($mysql,$debug=FALSE)
    {
        $this->mysql = $mysql;
        $this->Log = $GLOBALS['Log'];
		$this->debug_flag = $debug;
    }
	
	public function setdebug($debug_flag=TRUE)
	{
		$this->debug_flag = $debug_flag;
	}

    public function query($sql)
    {
        $result = array();
        
        if(empty($this->mysql))
        {
            $this->Log->error("sql object is empyt",__FILE__,__LINE__);
            return NULL;
        }
		
        $ret = $this->mysql->query($sql);
		
		if(!$ret)
		{
            $this->Log->error("Cannot excute $sql",__FILE__,__LINE__);
			return NULL;
		}
		
        while ($row = $ret->fetch_assoc())
        {   
            $result[] = $row;
        }
        if(empty($result))
        {
            return NULL;
        }
        else
        {
            return $result; 
        }
    }
	
	public function select($table, $select_data, $where_data)
	{
        if(empty($table) || empty($select_data) || !is_array($where_data))
        {
            $this->Log->error("select params error",__FILE__,__LINE__);
            return NULL;
        }

        $query = "SELECT $select_data FROM `$table` WHERE ";

        $fields = array_keys($where_data);
        $values = array_values($where_data);
        $total = count($where_data);

        for($i=0;$i<$total;$i++)
        {
            $query .= "{$fields[$i]} = {$values[$i]}";
            if($i < $total - 1)
            {
                $query .= " AND ";
            }
        }
		
		if($this->debug_flag)
		{
			$this->Log->notice("Excute: $query",__FILE__,__LINE__);
		}
		$ret = $this->query($query);
		
		return $ret;
	}
	
	public function insert($table, $insert_data, $ignore_flag = TRUE)
	{
        if(empty($table) || !is_array($insert_data))
        {
            $this->Log->error("insert params error",__FILE__,__LINE__);
            return FALSE;
        }

		$fields = implode(array_keys($insert_data), ',');
		$values = "'".implode(array_values($insert_data), "','")."'"; # better
		
		if($ignore_flag)
		{
			$insert_prefix = "INSERT IGNORE INTO";
		}
		else
		{
			$insert_prefix = "INSERT INTO";
		}

		$query = $insert_prefix.' `'.$table.'` ('.$fields.') VALUES ('.$values.')';
		
		if($this->debug_flag)
		{
			$this->Log->notice("Excute: $query",__FILE__,__LINE__);
		}
		$res = $this->mysql->query($query);
		
		if(!$res)
		{
			$this->Log->error("excute insert error: $query",__FILE__,__LINE__);
			return FALSE;
		}

		return TRUE;
	}
	
	public function update($table, $update_data, $where_data, $ignore_flag = TRUE)
	{
        if(empty($table) || !is_array($update_data) || !is_array($where_data))
        {
            $this->Log->error("update params error",__FILE__,__LINE__);
            return FALSE;
        }

		$fields = array_keys($update_data);
		$values = array_values($update_data);
        $total = count($update_data);
		
		if($ignore_flag)
		{
			$update_prefix = "UPDATE";
		}
		else
		{
			$update_prefix = "UPDATE IGNORE";
		}

        $query = $update_prefix.' `'.$table."` SET ";

        for($i=0;$i<$total;$i++)
        {
            $query .= $fields[$i]." = '".$values[$i]."'";
            if($i < $total - 1)
            {
                $query .= ", ";   
            }
        }

        $query .= " WHERE ";

        $fields = array_keys($where_data);
        $values = array_values($where_data);
        $total = count($where_data);

        for($i=0;$i<$total;$i++)
        {
            $query .= "{$fields[$i]} {$values[$i]}";
            if($i < $total - 1)
            {
                $query .= " AND ";
            }
        }
		
		if($this->debug_flag)
		{
			$this->Log->notice("Excute: $query",__FILE__,__LINE__);
		}        
		$res = $this->mysql->query($query);
		
		if(!$res)
		{
			$this->Log->error("excute update error: $query",__FILE__,__LINE__);
			return FALSE;
		}
		
		return TRUE;
	}

    public function close()
    {
        if(!empty($this->mysql))
        {
            $this->mysql->close();
        }
    }
}
