<?php

require_once("/home/iknow/workroot/yylib/yycommon.conf.php");

define('MAX_PROCESS',50000);

// get total count from WEIPU_ORIGIN_TABLE
$db = new yydb('mis');
$conn = $db->conn;

// get data from WEIPU_ORIGIN_TABLE
$sql = "select doc_id from doc order by doc_id desc limit 1";
$ret = $conn->query($sql);
$max_doc_id = $ret[0]['doc_id'];

var_dump($max_doc_id);

$doc_list = array();
$bar = new yybar();

while (count($doc_list) < MAX_PROCESS)
{
    $doc_id = rand(1,$max_doc_id);
    $sql = "select * from doc where doc_id = $doc_id";
    $ret = $conn->query($sql);
    if(!empty($ret[0]) && $ret[0]['main_status'] == 2)
    {
        $res = processDoc($ret[0]);
        if(!empty($res))
        {
            $doc_list[] = $res;
        }
    }
    $bar->drawbar(count($doc_list),MAX_PROCESS);
}

// Get online doc info
$yydoc = new yydoc();
$yydoc->addDoc($doc_list,'data');
$yydoc->setProxy(CURL_PROXY);
$yydoc->enableBar(TRUE);
$doc_list = $yydoc->excute();

// Table head
$csv_data = array();
$csv_head = array();
$head = array('Doc_ID','标题','链接','文档类型','文档大小','上传时间','页数','文档简介','关键词','文档财富值','评分','浏览量','下载量','收藏量','用户ID','用户名','用户等级','用户经验值','用户财富值','用户上传文档数','用户文档被下载数','用户创建文辑数',);
foreach ($head as $row)
{
    $csv_head[] = mb_convert_encoding($row, 'GBK','UTF-8');
}
$csv_data[] = $csv_head;

foreach ($doc_list as $row)
{
    $record = array();
    $record[] = $row['doc_id'];
    $record[] = $row['title'];
    $record[] = $row['wenku_url'];
    $record[] = $row['file_type'];
    $record[] = $row['size'];
    $record[] = $row['create_time'];
    $record[] = $row['page'];
    $record[] = $row['summary'];
    $record[] = $row['tag_str'];
    $record[] = $row['price'];
    $record[] = $row['doc_star'];
    $record[] = $row['viewCount'];
    $record[] = $row['downloadCount'];
    $record[] = $row['cangCount'];
    $record[] = $row['uid'];
    $record[] = $row['uname'];
    $record[] = $row['gradeLevel'];
    $record[] = $row['exp'];
    $record[] = $row['wealth'];
    $record[] = $row['passed'];
    $record[] = $row['bedownload'];
    $record[] = $row['album_passed'];
    $csv_data[] = $record;
}

$filename = DATA_PATH."yuanyuan.csv";
$mycsv = new yytable();
$mycsv->buildCsvTable($filename,$csv_data,'w');


function processDoc($record)
{
    if(empty($record))
    {
        return NULL;
    }

    $uid = $record['uid'];
    $table_id = floor($uid/50000000) + 1;

    $table_name = 'uscore'.$table_id;

    $db = new yydb('uscore');
    $conn = $db->conn;

    // get data from WEIPU_ORIGIN_TABLE
    $sql = "select * from $table_name where uid = $uid";
    $ret = $conn->query($sql);

    if(empty($ret))
    {
        $GLOBALS['Log']->error("Get uid $uid error",__FILE__,__LINE__);
        return NULL;
    }
    $ret = $ret[0];
    $record['exp'] = $ret['exp'];
    $record['wealth'] = $ret['wealth'];
    $record['passed'] = $ret['passed'];
    $record['bedownload'] = $ret['bedownload'];
    $record['album_passed'] = $ret['album_passed'];
    $record['gradeLevel'] = getLevel($ret['exp']);

    return $record;

}

function getLevel($exp)
{
    $level_score = array(
        50,
        500,
        1000,
        2500,
        5000,
        9000,
        13000,
        19000,
        26000,
        999999999,
    );

    $level_name = array(
        "一级",
        "二级",
        "三级",
        "四级",
        "五级",
        "六级",
        "七级",
        "八级",
        "九级",
        "十级",
    );

    $level = 0;

    foreach ($level_score as $key => $row)
    {
        if($exp <= $row)
        {
            $level = $key;
            break;
        }
    }
    // 返回数值
    return $level;
    // 返回级别
    //return mb_convert_encoding($level_name[$level],"GBK","UTF-8");
}
